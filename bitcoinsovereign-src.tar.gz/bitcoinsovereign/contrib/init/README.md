Sample configuration files for:
```
SystemD: bitcoinsovereignd.service
Upstart: bitcoinsovereignd.conf
OpenRC:  bitcoinsovereignd.openrc
         bitcoinsovereignd.openrcconf
CentOS:  bitcoinsovereignd.init
OS X:    org.bitcoinsovereign.bitcoinsovereignd.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
